/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main() 
{
    int i, j,r;
    printf("enter the number of row:");
    scanf("%d",&r);
    for (i = 1; i <= r; i++)
    {
        for (j = 1; j <= i; j++) 
        {
            printf("%.1f ",(float)j/10);
        }
        printf("\n");
    }
    return 0;
}